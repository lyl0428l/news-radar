"""
爬虫基类 - 所有站点爬虫的统一接口
"""
import re
import random
import time
import logging
import requests
from abc import ABC, abstractmethod
from datetime import datetime, timedelta
from dataclasses import dataclass, field
from typing import Optional

import sys
import os
from email.utils import parsedate_to_datetime

sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))
from config import USER_AGENTS, CRAWL_TIMEOUT, CRAWL_RETRY, CRAWL_DELAY

TOP_N = 10  # 每个站点只保留 TOP 10

# 标题最短有效长度（中文约 4 个汉字=8字节，英文约 10 个字符）
# 低于此阈值的文本多为导航/按钮/标签，不是新闻标题
MIN_TITLE_LEN_ZH = 6   # 中文标题最短字符数
MIN_TITLE_LEN_EN = 10  # 英文标题最短字符数


@dataclass
class NewsItem:
    """标准化新闻条目数据类"""
    title: str = ""
    url: str = ""
    source: str = ""
    source_name: str = ""
    summary: str = ""
    content: str = ""
    category: str = ""
    rank: int = 0
    pub_time: str = ""
    crawl_time: str = ""
    language: str = "zh"
    extra: dict = field(default_factory=dict)

    def to_dict(self) -> dict:
        return {
            "title": self.title,
            "url": self.url,
            "source": self.source,
            "source_name": self.source_name,
            "summary": self.summary,
            "content": self.content,
            "category": self.category,
            "rank": self.rank,
            "pub_time": self.pub_time,
            "crawl_time": self.crawl_time,
            "language": self.language,
            "extra": self.extra,
        }


# ========== 相对时间解析的正则 ==========
_RELATIVE_PATTERNS = [
    (re.compile(r"(\d+)\s*秒前"), lambda m: timedelta(seconds=int(m.group(1)))),
    (re.compile(r"(\d+)\s*分钟前"), lambda m: timedelta(minutes=int(m.group(1)))),
    (re.compile(r"(\d+)\s*分前"), lambda m: timedelta(minutes=int(m.group(1)))),
    (re.compile(r"(\d+)\s*小时前"), lambda m: timedelta(hours=int(m.group(1)))),
    (re.compile(r"(\d+)\s*天前"), lambda m: timedelta(days=int(m.group(1)))),
    (re.compile(r"昨天"), lambda m: timedelta(days=1)),
    (re.compile(r"前天"), lambda m: timedelta(days=2)),
]

# 绝对时间格式
_DATETIME_FORMATS = [
    "%Y-%m-%d %H:%M:%S",
    "%Y-%m-%d %H:%M",
    "%Y-%m-%dT%H:%M:%S",
    "%Y-%m-%dT%H:%M:%SZ",
    "%Y-%m-%dT%H:%M:%S+08:00",
    "%Y/%m/%d %H:%M:%S",
    "%Y/%m/%d %H:%M",
    "%Y-%m-%d",
    "%Y/%m/%d",
    "%m-%d %H:%M",
    "%m月%d日 %H:%M",
]


class BaseCrawler(ABC):
    """爬虫基类，所有站点爬虫继承此类并实现 crawl() 方法"""

    def __init__(self):
        self.name = ""            # 站点标识，如 "sina"
        self.display_name = ""    # 站点中文名，如 "新浪新闻"
        self.language = "zh"      # zh / en
        self.logger = logging.getLogger(self.__class__.__name__)
        self.session = self._build_session()

    def _build_session(self) -> requests.Session:
        """构建 requests Session，带默认 UA 和超时"""
        s = requests.Session()
        s.headers.update({
            "User-Agent": random.choice(USER_AGENTS),
            "Accept": "text/html,application/xhtml+xml,application/xml;q=0.9,*/*;q=0.8",
            "Accept-Language": "zh-CN,zh;q=0.9,en;q=0.8",
        })
        return s

    def _request(self, url: str, method="GET", **kwargs) -> Optional[requests.Response]:
        """
        带重试和延迟的请求方法。
        每次请求使用独立的随机 UA（线程安全）。
        失败返回 None。
        """
        kwargs.setdefault("timeout", CRAWL_TIMEOUT)
        # 提前取出 caller 传的 headers，避免在重试循环中被 pop 丢失
        caller_headers = dict(kwargs.pop("headers", {}))

        for attempt in range(1, CRAWL_RETRY + 1):
            try:
                # 每次重试都带上 caller headers + 随机 UA
                headers = dict(caller_headers)
                headers["User-Agent"] = random.choice(USER_AGENTS)
                resp = self.session.request(method, url, headers=headers, **kwargs)
                resp.raise_for_status()
                # 编码检测：防止 GBK 页面乱码
                if resp.encoding and resp.encoding.lower() in ("iso-8859-1",):
                    resp.encoding = resp.apparent_encoding
                return resp
            except requests.RequestException as e:
                self.logger.warning(f"[{self.name}] 请求失败 (第{attempt}次): {url} | {e}")
                if attempt < CRAWL_RETRY:
                    delay = random.uniform(*CRAWL_DELAY)
                    time.sleep(delay)

        return None

    def _make_item(self, title: str, url: str, rank: int = 0,
                   summary: str = "", category: str = "",
                   pub_time: str = "", content: str = "",
                   extra: Optional[dict] = None) -> dict:
        """构造标准新闻条目，rank 为热榜排名（1=最热）"""
        return {
            "title": title.strip() if title else "",
            "url": url.strip() if url else "",
            "source": self.name,
            "source_name": self.display_name,
            "summary": summary.strip() if summary else "",
            "content": content.strip() if content else "",
            "category": category.strip() if category else "",
            "rank": rank,
            "pub_time": pub_time.strip() if pub_time else "",
            "crawl_time": datetime.now().strftime("%Y-%m-%d %H:%M:%S"),
            "language": self.language,
            "extra": extra or {},
        }

    # ========== 工具方法 ==========

    def parse_time(self, raw: str) -> str:
        """
        统一时间解析，支持：
        - 相对时间: '3分钟前', '2小时前', '昨天', '前天'
        - 绝对时间: '2026-03-11 14:00:00', '2026/03/11'
        - 时间戳: 秒级(10位) 或 毫秒级(13位)
        返回标准格式 'YYYY-MM-DD HH:MM:SS'，解析失败返回空字符串。
        """
        if not raw:
            return ""
        raw = raw.strip()

        # 1. 尝试时间戳（纯数字）
        if raw.isdigit():
            ts = int(raw)
            if ts > 1e12:  # 毫秒级
                ts = ts // 1000
            try:
                return datetime.fromtimestamp(ts).strftime("%Y-%m-%d %H:%M:%S")
            except (ValueError, OSError):
                return ""

        # 1.5 尝试 RFC 2822 格式（RSS 常用，如 "Mon, 10 Mar 2026 14:30:00 GMT"）
        try:
            dt = parsedate_to_datetime(raw)
            return dt.strftime("%Y-%m-%d %H:%M:%S")
        except Exception:
            pass

        # 2. 尝试相对时间
        for pattern, delta_fn in _RELATIVE_PATTERNS:
            m = pattern.search(raw)
            if m:
                dt = datetime.now() - delta_fn(m)
                return dt.strftime("%Y-%m-%d %H:%M:%S")

        # 3. 尝试绝对时间格式
        for fmt in _DATETIME_FORMATS:
            try:
                dt = datetime.strptime(raw, fmt)
                # 缺年份的格式补当年
                if dt.year == 1900:
                    dt = dt.replace(year=datetime.now().year)
                return dt.strftime("%Y-%m-%d %H:%M:%S")
            except ValueError:
                continue

        # 4. 都失败了，返回空串
        return ""

    def clean_text(self, html: str) -> str:
        """HTML → 纯文本：去标签、去多余空白"""
        if not html:
            return ""
        try:
            from bs4 import BeautifulSoup
            soup = BeautifulSoup(html, "lxml")
            # 去除 script/style
            for tag in soup(["script", "style", "iframe", "noscript"]):
                tag.decompose()
            text = soup.get_text(separator="\n")
        except Exception:
            # fallback: 简单正则去标签
            text = re.sub(r"<[^>]+>", "", html)

        # 合并多个空白行/空格
        text = re.sub(r"\n\s*\n", "\n", text)
        text = re.sub(r"[ \t]+", " ", text)
        return text.strip()

    def extract_summary(self, content: str, max_len: int = 200) -> str:
        """从全文提取摘要：取前 max_len 字符，在标点处截断"""
        if not content:
            return ""
        text = content[:max_len + 50]  # 多取一些以便找截断点
        if len(text) > max_len:
            # 在标点处截断
            for punct in ("。", "！", "？", ".", "!", "?", "；", ";"):
                idx = text.rfind(punct, 0, max_len + 1)
                if idx > max_len // 2:
                    return text[:idx + 1]
            return text[:max_len] + "..."
        return text

    def validate(self, items: list) -> list:
        """
        过滤无效数据：
        - 空标题或空 URL
        - 标题过短 (< 4 字符)
        - pub_time 在未来 (解析错误)
        - URL 格式非法
        """
        valid = []
        now = datetime.now()
        for item in items:
            title = item.get("title", "").strip() if isinstance(item, dict) else ""
            url = item.get("url", "").strip() if isinstance(item, dict) else ""

            if not title or not url:
                continue
            if len(title) < 4:
                continue
            if not url.startswith(("http://", "https://")):
                continue

            # 检查时间是否在未来（超过 1 小时视为解析错误）
            pub_time = item.get("pub_time", "")
            if pub_time:
                try:
                    pt = datetime.strptime(pub_time, "%Y-%m-%d %H:%M:%S")
                    if pt > now + timedelta(hours=1):
                        item["pub_time"] = ""  # 清除错误时间
                except ValueError:
                    pass

            valid.append(item)

        return valid

    # ========== 核心接口 ==========

    @abstractmethod
    def crawl(self) -> list[dict]:
        """
        执行爬取，返回热榜 TOP 10 新闻列表。
        每个子类必须实现此方法。
        返回的列表按热度排序，rank=1 为最热。
        """
        pass

    def run(self) -> list[dict]:
        """执行爬取，验证+截断为 TOP 10。异常向上抛出，由调用方重试。"""
        self.logger.info(f"[{self.name}] 开始爬取: {self.display_name}")
        results = self.crawl()
        # 验证数据有效性
        results = self.validate(results)
        # 强制截断为 TOP 10
        results = results[:TOP_N]
        self.logger.info(f"[{self.name}] 爬取完成: {len(results)} 条 (TOP {TOP_N})")
        return results


class RSSCrawler(BaseCrawler):
    """
    通用 RSS 爬虫基类。
    子类只需设置 name / display_name / language / rss_url / category 即可。
    自动处理：请求 → feedparser 解析 → 去重 → 标准化输出。
    """
    rss_url: str = ""
    category: str = "Top Stories"

    def crawl(self) -> list[dict]:
        results = []
        if not self.rss_url:
            return results

        resp = self._request(self.rss_url)
        if resp is None:
            return results

        try:
            import feedparser
            feed = feedparser.parse(resp.content)
        except Exception as e:
            self.logger.warning(f"[{self.name}] RSS 解析失败: {e}")
            return results

        seen = set()
        for i, entry in enumerate(feed.entries[:10], 1):
            title = str(entry.get("title", "")).strip()
            link = str(entry.get("link", "")).strip()
            if not title or not link or link in seen:
                continue
            seen.add(link)

            summary = str(entry.get("summary", ""))
            # 仅当摘要含 HTML 标签时才清洗
            if summary and "<" in summary and ">" in summary:
                summary = self.clean_text(summary)[:200]
            else:
                summary = summary[:200]

            results.append(self._make_item(
                title=title,
                url=link,
                rank=i,
                summary=summary,
                category=self.category,
                pub_time=self.parse_time(str(entry.get("published", ""))),
            ))

        return results
